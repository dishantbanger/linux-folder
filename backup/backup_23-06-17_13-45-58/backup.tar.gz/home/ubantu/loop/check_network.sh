#!/bin/bash

for x in ubantu.com,youtube.com.facebook.com,google.com
do 
if ping -q -c 2 -w 1 $x > /dev/null;then
echo "$x is up"
else
echo "$x id down"
fi
done
