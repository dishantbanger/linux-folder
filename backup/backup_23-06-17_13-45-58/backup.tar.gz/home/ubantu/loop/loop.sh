#!/bin/bash
x=1
for x in {1..5}
do 
echo "u had $x number to tea"
done
 
