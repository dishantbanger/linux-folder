#!/bin/bash

for x in ajmer;  #(cat cities.txt)
do
weather=$(curl -s http://wttr.in/$x format=3)
echo "weather for $weather"
done

