#!/bin/bash
 
x=1
file=readfile.txt
while read -r line;
do
echo "$line"
done < $file


x=2
while (( x<20 ));
do 

echo $x
(( x +=2 ))
done

#while loop to perform operator on a file 
while read a b c
do
echo $b - $a
done < readfile.txt
