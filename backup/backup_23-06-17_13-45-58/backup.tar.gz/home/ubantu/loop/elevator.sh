#!/bin/bash

echo "welcome to the taj elevator"
echo "which floor u want to go"
for x in {1..10};
do
if [[ $x == 5 ]]; then
continue #break
fi
echo "floor $x"
done
