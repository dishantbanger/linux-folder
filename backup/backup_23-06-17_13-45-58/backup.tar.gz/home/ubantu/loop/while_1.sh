#!/bin/bash
x=1

while [[ $x -le 10 ]];
do
echo "complete your $x set"
read -p "press enter for nxt set"
(( x ++))
done
 
